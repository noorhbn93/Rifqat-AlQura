package com.abozeen.rifqat;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.ValueCallback;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQUEST_EXPORT = 501;
    private static final int REQUEST_IMPORT = 502;
    private static final int REQUEST_PHOTO = 503;
    private WebView webView;
    private AppDb db;
    private String pendingBackup = "";
    private ValueCallback<Uri[]> photoFileCallback;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(20, 84, 63));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(20, 84, 63));
        db = new AppDb(this);
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(247, 245, 237));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setDefaultTextEncodingName("UTF-8");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equals(uri.getScheme()) || "about".equals(uri.getScheme())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) { toast("تعذر فتح الرابط"); }
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (photoFileCallback != null) photoFileCallback.onReceiveValue(null);
                photoFileCallback = callback;
                Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("image/*");
                try { startActivityForResult(Intent.createChooser(pick, "اختر صورة الحافظ"), REQUEST_PHOTO); return true; }
                catch (Exception e) { photoFileCallback = null; callback.onReceiveValue(null); return false; }
            }
        });
        webView.addJavascriptInterface(new AppBridge(), "Rifqat");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    private void toast(String text) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, text, Toast.LENGTH_SHORT).show());
    }

    private class AppBridge {
        @JavascriptInterface public String getAll() { return db.exportJson().toString(); }
        @JavascriptInterface public String getQuranText() {
            try (InputStream in = getAssets().open("quran/quran_uthmani.txt"); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                return out.toString("UTF-8");
            } catch (Exception e) { return ""; }
        }
        @JavascriptInterface public long saveMemorizer(String json) {
            try { return db.saveMemorizer(new JSONObject(json)); }
            catch (Exception e) { return -1; }
        }
        @JavascriptInterface public boolean deleteMemorizer(long id) { return db.deleteMemorizer(id); }
        @JavascriptInterface public long saveSession(String json) {
            try { return db.saveSession(new JSONObject(json)); }
            catch (Exception e) { return -1; }
        }
        @JavascriptInterface public boolean deleteSession(long id) { return db.deleteSession(id); }
        @JavascriptInterface public long saveBookmark(String json) {
            try { return db.saveBookmark(new JSONObject(json)); }
            catch (Exception e) { return -1; }
        }
        @JavascriptInterface public boolean deleteBookmark(long id) { return db.deleteBookmark(id); }
        @JavascriptInterface public void setSetting(String key, String value) { db.setSetting(key, value); }
        @JavascriptInterface public void exportBackup() {
            runOnUiThread(() -> {
                pendingBackup = db.exportJson().toString();
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE, "rifqat-alquran-backup.json");
                startActivityForResult(i, REQUEST_EXPORT);
            });
        }
        @JavascriptInterface public void importBackup() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                startActivityForResult(i, REQUEST_IMPORT);
            });
        }
        @JavascriptInterface public void showMessage(String text) { toast(text); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PHOTO) {
            if (photoFileCallback != null) {
                Uri[] result = resultCode == RESULT_OK && data != null && data.getData() != null ? new Uri[]{data.getData()} : null;
                photoFileCallback.onReceiveValue(result);
                photoFileCallback = null;
            }
            return;
        }
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (requestCode == REQUEST_EXPORT) {
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IllegalStateException("تعذر فتح الملف");
                    out.write(pendingBackup.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                }
                toast("تم تصدير النسخة الاحتياطية");
            } else if (requestCode == REQUEST_IMPORT) {
                try (InputStream in = getContentResolver().openInputStream(uri); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                    if (in == null) throw new IllegalStateException("تعذر فتح الملف");
                    byte[] buf = new byte[8192]; int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    db.importJson(new JSONObject(out.toString("UTF-8")));
                }
                webView.evaluateJavascript("window.appReload && window.appReload()", null);
                toast("تمت استعادة البيانات");
            }
        } catch (Exception e) {
            toast("تعذر إكمال العملية: " + e.getMessage());
        }
    }

    private static final class AppDb extends SQLiteOpenHelper {
        private static final String NAME = "rifqat_local.db";
        AppDb(Context c) { super(c, NAME, null, 1); }
        @Override public void onConfigure(SQLiteDatabase db) { super.onConfigure(db); db.setForeignKeyConstraintsEnabled(true); }
        @Override public void onCreate(SQLiteDatabase d) {
            d.execSQL("CREATE TABLE memorizers(id INTEGER PRIMARY KEY AUTOINCREMENT, full_name TEXT NOT NULL, region TEXT, phone TEXT, start_date TEXT, teacher TEXT, level TEXT, notes TEXT, photo_uri TEXT)");
            d.execSQL("CREATE TABLE sessions(id INTEGER PRIMARY KEY AUTOINCREMENT, memorizer_id INTEGER NOT NULL, surah_id INTEGER NOT NULL, from_ayah INTEGER NOT NULL, to_ayah INTEGER NOT NULL, session_type TEXT NOT NULL, session_date TEXT NOT NULL, teacher TEXT, evaluation TEXT, notes TEXT, show_ayah INTEGER NOT NULL DEFAULT 1, FOREIGN KEY(memorizer_id) REFERENCES memorizers(id) ON DELETE CASCADE)");
            d.execSQL("CREATE INDEX sessions_mem_date ON sessions(memorizer_id, session_date)");
            d.execSQL("CREATE TABLE bookmarks(id INTEGER PRIMARY KEY AUTOINCREMENT, memorizer_id INTEGER NOT NULL DEFAULT 0, surah_id INTEGER NOT NULL, ayah_number INTEGER NOT NULL, label TEXT, UNIQUE(memorizer_id,surah_id,ayah_number))");
            d.execSQL("CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT)");
        }
        @Override public void onUpgrade(SQLiteDatabase d, int oldVersion, int newVersion) { }

        synchronized long saveMemorizer(JSONObject j) throws JSONException {
            SQLiteDatabase d = getWritableDatabase();
            ContentValues v = new ContentValues();
            put(v,"full_name",j,"full_name"); put(v,"region",j,"region"); put(v,"phone",j,"phone");
            put(v,"start_date",j,"start_date"); put(v,"teacher",j,"teacher"); put(v,"level",j,"level");
            put(v,"notes",j,"notes"); put(v,"photo_uri",j,"photo_uri");
            long id = j.optLong("id",0);
            if (id > 0) { d.update("memorizers",v,"id=?",new String[]{String.valueOf(id)}); return id; }
            return d.insertOrThrow("memorizers",null,v);
        }
        synchronized boolean deleteMemorizer(long id) { return getWritableDatabase().delete("memorizers","id=?",new String[]{String.valueOf(id)}) > 0; }
        synchronized long saveSession(JSONObject j) throws JSONException {
            ContentValues v = new ContentValues();
            v.put("memorizer_id",j.getLong("memorizer_id")); v.put("surah_id",j.getInt("surah_id"));
            v.put("from_ayah",j.getInt("from_ayah")); v.put("to_ayah",j.getInt("to_ayah"));
            v.put("session_type",j.getString("session_type")); v.put("session_date",j.getString("session_date"));
            put(v,"teacher",j,"teacher"); put(v,"evaluation",j,"evaluation"); put(v,"notes",j,"notes");
            v.put("show_ayah",j.optBoolean("show_ayah",true)?1:0);
            return getWritableDatabase().insertOrThrow("sessions",null,v);
        }
        synchronized boolean deleteSession(long id) { return getWritableDatabase().delete("sessions","id=?",new String[]{String.valueOf(id)}) > 0; }
        synchronized long saveBookmark(JSONObject j) throws JSONException {
            ContentValues v = new ContentValues(); v.put("memorizer_id",j.optLong("memorizer_id",0));
            v.put("surah_id",j.getInt("surah_id")); v.put("ayah_number",j.getInt("ayah_number")); put(v,"label",j,"label");
            long id = getWritableDatabase().insertWithOnConflict("bookmarks",null,v,SQLiteDatabase.CONFLICT_REPLACE);
            return id;
        }
        synchronized boolean deleteBookmark(long id) { return getWritableDatabase().delete("bookmarks","id=?",new String[]{String.valueOf(id)}) > 0; }
        synchronized void setSetting(String key,String value) { ContentValues v=new ContentValues();v.put("key",key);v.put("value",value);getWritableDatabase().insertWithOnConflict("settings",null,v,SQLiteDatabase.CONFLICT_REPLACE); }

        private static void put(ContentValues v,String col,JSONObject j,String key) { v.put(col,j.isNull(key)?"":j.optString(key,"")); }
        private static JSONArray table(SQLiteDatabase d,String name) throws JSONException {
            JSONArray a=new JSONArray(); Cursor c=d.rawQuery("SELECT * FROM "+name+" ORDER BY id",null);
            try { while(c.moveToNext()) { JSONObject o=new JSONObject(); for(int i=0;i<c.getColumnCount();i++) { String k=c.getColumnName(i); int t=c.getType(i); if(t==Cursor.FIELD_TYPE_INTEGER)o.put(k,c.getLong(i)); else if(t==Cursor.FIELD_TYPE_FLOAT)o.put(k,c.getDouble(i)); else if(t==Cursor.FIELD_TYPE_NULL)o.put(k,JSONObject.NULL); else o.put(k,c.getString(i)); } a.put(o); } }
            finally { c.close(); } return a;
        }
        synchronized JSONObject exportJson() {
            JSONObject out=new JSONObject();
            try { SQLiteDatabase d=getReadableDatabase(); out.put("format","rifqat-backup-v1"); out.put("memorizers",table(d,"memorizers")); out.put("sessions",table(d,"sessions")); out.put("bookmarks",table(d,"bookmarks"));
                JSONArray settings=new JSONArray(); Cursor c=d.rawQuery("SELECT key,value FROM settings ORDER BY key",null); try { while(c.moveToNext()){JSONObject o=new JSONObject();o.put("key",c.getString(0));o.put("value",c.getString(1));settings.put(o);} } finally {c.close();} out.put("settings",settings);
            } catch(Exception ignored) { } return out;
        }
        synchronized void importJson(JSONObject in) throws JSONException {
            if (!"rifqat-backup-v1".equals(in.optString("format"))) throw new JSONException("صيغة النسخة الاحتياطية غير مدعومة");
            SQLiteDatabase d=getWritableDatabase(); d.beginTransaction();
            try {
                d.delete("sessions",null,null); d.delete("bookmarks",null,null); d.delete("memorizers",null,null); d.delete("settings",null,null);
                JSONArray mem=in.optJSONArray("memorizers"); if(mem!=null) for(int i=0;i<mem.length();i++){JSONObject o=mem.getJSONObject(i); ContentValues v=new ContentValues();v.put("id",o.optLong("id"));for(String k:new String[]{"full_name","region","phone","start_date","teacher","level","notes","photo_uri"})v.put(k,o.optString(k,""));d.insertOrThrow("memorizers",null,v);}
                JSONArray ses=in.optJSONArray("sessions"); if(ses!=null) for(int i=0;i<ses.length();i++){JSONObject o=ses.getJSONObject(i);ContentValues v=new ContentValues();for(String k:new String[]{"id","memorizer_id","surah_id","from_ayah","to_ayah","show_ayah"})v.put(k,o.optLong(k));for(String k:new String[]{"session_type","session_date","teacher","evaluation","notes"})v.put(k,o.optString(k,""));d.insertOrThrow("sessions",null,v);}
                JSONArray bm=in.optJSONArray("bookmarks"); if(bm!=null) for(int i=0;i<bm.length();i++){JSONObject o=bm.getJSONObject(i);ContentValues v=new ContentValues();v.put("id",o.optLong("id"));v.put("memorizer_id",o.optLong("memorizer_id"));v.put("surah_id",o.optInt("surah_id"));v.put("ayah_number",o.optInt("ayah_number"));v.put("label",o.optString("label",""));d.insertOrThrow("bookmarks",null,v);}
                JSONArray st=in.optJSONArray("settings"); if(st!=null) for(int i=0;i<st.length();i++){JSONObject o=st.getJSONObject(i);ContentValues v=new ContentValues();v.put("key",o.getString("key"));v.put("value",o.optString("value",""));d.insertOrThrow("settings",null,v);}
                d.setTransactionSuccessful();
            } finally { d.endTransaction(); }
        }
    }
}
